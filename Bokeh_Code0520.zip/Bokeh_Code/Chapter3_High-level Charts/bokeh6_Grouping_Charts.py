#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat May 20 07:28:13 2017

@author: jerry
"""

##Grouping

from bokeh.charts import Bar, output_file, show
from bokeh.sampledata.autompg import autompg as df

p = Bar(df, label='yr', values='mpg', agg='median', group='origin',
        title="Median MPG by YR, grouped by ORIGIN", legend='top_right')

#output_file("bar.html")

show(p)

##Stacking
from bokeh.charts import Bar, output_file, show
from bokeh.sampledata.autompg import autompg as df

p = Bar(df, label='origin', values='mpg', agg='mean', stack='cyl',
        title="Avg MPG by ORIGIN, stacked by CYL", legend='top_right')

#output_file("bar.html")

show(p)