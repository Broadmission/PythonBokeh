#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 19 19:21:35 2017

@author: jerry
"""
#####Pie Chart

from bokeh.charts import Donut, show
import pandas as pd
data = pd.Series([0.15,0.4,0.7,1.0], index = list('abcd'))
pie_chart = Donut(data)
show(pie_chart)


