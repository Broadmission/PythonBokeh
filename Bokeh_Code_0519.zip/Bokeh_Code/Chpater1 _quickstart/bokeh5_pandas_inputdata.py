#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  2 12:08:02 2017

@author: jerry
"""
import pandas as pd
from bokeh.plotting import figure
from bokeh.io import output_file, show

df = pd.read_csv('stock.csv', 
                 encoding = 'big5',
                 sep = ',',
                 header = 1)

df = df[0:115]
df.columns = ['Index','Closing_Index','Gains','Gains_index','Gains_percentage']


### Viewing Data
#df.dtypes
#df.describe()
#df.head(2)
#df.tail(1)
#df.T
#df.sort_values(by='Gains_percentage', ascending=False)
#ascending=FALSE 從大排到小，反之從小排到大

##
#Renaming columns in pandas
#df.dtypes
#df.columns = ['Index','Closing_Index','Gains','Gains_index','Gains_percentage']

#### Selection
#df['Closing_Index'].head(9)
#df[0:3]
## Selection by Label
#df.loc[:,['Index','Closing_Index']].head(5)
## Selection by Position
#df.iloc[1:10,0:2] [列,行]

#Filling missing data
#df.dropna(how='any')
#df1.fillna(value=5)

### Merge
#xx = x + y
#xx_pd=pd.DataFrame(xx)
#pd.concat([xx_pd,xx_pd],axis=1) #行合併
#pd.concat([xx_pd,xx_pd],axis=0) #列合併

#df.drop(df.index[[0,1]])


p = figure(x_axis_label='收盤指數',
           y_axis_label='漲跌點數',
           title = '106年03月31日大盤統計資訊')

p.circle(df['Closing_Index'],
         df['Gains_index'], size=10)

#output_file('stock-df.html')
show(p)

