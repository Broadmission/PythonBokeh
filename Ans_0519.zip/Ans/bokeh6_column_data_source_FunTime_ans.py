#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr  2 12:08:02 2017

@author: jerry
"""
import pandas as pd
from bokeh.plotting import figure
from bokeh.io import output_file, show
from bokeh.plotting import ColumnDataSource

df = pd.read_csv('stock.csv', 
                 encoding = 'big5',
                 sep = ',',
                 header = 1)

df = df[0:115]
df.columns = ['Index','Closing_Index','Gains','Gains_index','Gains_percentage']

source = ColumnDataSource(df)

p = figure(x_axis_label='收盤指數',
           y_axis_label='漲跌點數',
           title = '106年03月31日大盤統計資訊')

p.circle(x = 'Closing_Index',
         y = 'Gains_index',
         source=source,
         size=10)

#output_file('stock-df.html')
show(p)



