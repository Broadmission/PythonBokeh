from bokeh.io import output_file, show 
from bokeh.plotting import figure

plot = figure(plot_width=400,
              tools='pan,box_zoom',
              x_axis_label='x',
              y_axis_label='y')
plot.circle(x=[10,11,12,13], y=[2,5,8,12])

show(plot)





